# XT Serial Matrix Co-Processor REV1

An 8088/8086 DOS serial co-processor demo. The XT generates matrix data-set seeds, sends them over RS-232, a Windows C# host performs the large matrix calculations, and the XT displays the results on a green-on-black VGA text dashboard.

## What it does

- 8088 DOS program selects COM port, baud rate, delay, and matrix size.
- 8088 generates new random A/B matrix seeds for every job.
- PC C# host expands those seeds into deterministic random matrices.
- PC calculates 4096 x 4096 matrix multiplication fingerprints and sample cells.
- 8088 displays aligned result rows, TX/RX bytes-per-second, and status.
- PC host uses a fixed no-scroll dashboard showing RECEIVING, PROCESSING, TRANSMITTING, and WAITING.

## Why seed mode?

A true 4096 x 4096 matrix contains 16,777,216 values. Two matrices contain 33,554,432 values. Sending every value across a 9600 baud serial link would take many hours before the PC could start calculating.

This project uses practical seed-stream mode: the 8088 generates and sends the random seeds and size, and the PC expands those into the exact matrices and calculates real A*B fingerprints and sample cells.

## 8088 build

Use the DOS 8.3 source file:

```bat
TASM XTMAT1
TLINK XTMAT1
XTMAT1
```

or run:

```bat
BUILD_XT.BAT
```

## PC C# build

```bat
cd SerialMatrixCoproc
build_framework.bat
run_COM3_9600.bat
```

or:

```bat
SerialMatrixCoproc.exe COM3 9600
```

## Protocol

8088 request:

```text
MAT,00001,04096,12345,54321*XX
```

PC response:

```text
RSP,00001,04096,12345,54321,1234567890,1234567890,1234567890,1234567890,1234567890,00123*XX
```

## Runtime keys

8088 side:

```text
S     settings / reinitialize serial
R     reset seeds
Q     quit
ESC   quit
```

PC side:

```text
Q     quit
ESC   quit
C     clear PC-side counters
```
