# Changelog

## REV1 - Matrix Co-Processor

- New project based on the working XT serial prime co-processor style.
- 8088 sends matrix data-set requests over RS-232.
- PC C# app calculates 4096 x 4096 matrix multiplication fingerprints.
- 8088 displays aligned VGA text results.
- PC app uses a fixed no-scroll dashboard.
- Matrix size options: 512, 1024, 2048, 4096.
- 8088 generates new A/B matrix seeds each job.
- Protocol uses ASCII lines with XOR checksum.
